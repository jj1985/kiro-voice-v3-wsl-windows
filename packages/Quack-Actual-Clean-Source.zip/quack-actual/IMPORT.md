# Start a fresh repository

This directory is source-only: application code, tests, installers, launchers,
locked dependency specifications, documentation, and packaging scripts. It has
no Git object database, branches, tags, remotes, author records, credentials,
installed virtual environments, model cache, or personal configuration.

## 1. Extract into a new directory

Use a new, empty directory outside any existing checkout. Do not clone, fork,
copy an existing `.git` directory, or extract over an older installation.
The package folder can be named `quack-actual` and contains `install.ps1`.
Do not create the virtual environment until the folder is in its final location.

## 2. Create the repository under your corporate identity

Open PowerShell in this directory. Before initialization, the following should
print `False`:

```powershell
Test-Path -LiteralPath .git
```

Use your organization's approved Git installation and normal Git configuration.
If `GIT_DIR`, `GIT_WORK_TREE`, or Git author/committer environment overrides are
set in your shell, resolve them before starting: they can override the location
or identity you intend to use. Do not copy personal credential stores or keys.

```powershell
git init --initial-branch=main
git config --local user.name (Read-Host 'Corporate commit name')
git config --local user.email (Read-Host 'Corporate commit email')

# Verify both identities before committing; they should be your corporate values.
git var GIT_AUTHOR_IDENT
git var GIT_COMMITTER_IDENT
```

The local identity settings apply to this repository, not all repositories on
the laptop. Keep any signing, hooks, and authentication controls required by
your organization. Author configuration does not select your remote login.

After checking the identity output:

```powershell
git add .
git diff --cached --stat
git commit -m 'Initial import of Quack Actual'
git log -1 --format=fuller
git rev-list --count HEAD
```

The last command should print `1`. The initial commit has no inherited parents.
Then create an empty destination repository through your approved corporate
service, authenticate there with your corporate account, and run:

```powershell
git remote add origin (Read-Host 'Empty corporate repository URL')
git remote -v
git push -u origin main
```

Stop and inspect any error before proceeding to the next command. Do not
force-push to replace an existing destination repository.

## 3. Install locally

The source includes everything required to build the application and initiate
online setup, not offline copies of Python, speech models, or vendor CLIs.

```powershell
.\install.ps1
.\launch.ps1 doctor --backend copilot
.\launch.ps1 start --backend copilot --project C:\src\my-project
```

The installer uses uv, managed Python 3.12 and a new `.venv`. Use
`.\install.ps1 -NoBootstrap` when uv has already been provisioned through your
approved software process. This flag prevents automatic uv bootstrapping; other
required downloads can still occur. Follow corporate execution, proxy, package
registry, and AI-tool policies rather than disabling those controls. Install and
authenticate the selected coding CLI separately. Use `--text-only` on the start
command for a first keyboard-only test. See README.md for WSL instructions.

Local virtual environments and ordinary local settings are ignored by the
included `.gitignore`. Review staged changes before every commit.

## 4. Test and build

With an approved uv installation available:

```powershell
uv run --locked python scripts/release_audit.py
uv run --locked python -m unittest discover -s tests -v
uv build --python 3.12
uv run --locked python scripts/build_release.py
uv run --locked python scripts/verify_release.py dist
```

The explicit RELEASE-FILES.txt list controls source/setup packaging. Update it
when intentionally adding or moving distributable files.

## Optional release automation is disabled

`ci-templates/release.yml.disabled` is a retained workflow example, not an active
GitHub Actions workflow. A first push therefore does not activate that workflow
or publish a release. Review it with your organization before enabling it. It
includes a write-enabled publish job and uses the destination repository's
runtime identity, not a preconfigured personal remote.

To enable it deliberately on GitHub, move it to `.github/workflows/release.yml`,
update RELEASE-FILES.txt, and update MANIFEST.in to include the active workflow.
Other corporate Git hosts require their own CI configuration.

## Scope

This handoff includes the reviewed distribution fixes and does not alter any
remote repository. The application runtime is unchanged from the reviewed code.
Only the workflow location, source-distribution manifests, and this import guide
are adjusted for the handoff. Existing documentation and third-party notices
are retained. No project license is selected by this package; follow your
organization's ownership and licensing approval process. Removing Git metadata
starts new technical history; it does not change legal ownership or licenses.

Git references: https://git-scm.com/docs/git-init and
https://git-scm.com/docs/git-config
